from .executor_controller import print_available_executors,create_master_executor,save_last_executor
from .inquirer_controller import inquirer_using_selected_system_instructions , auto_import_inquirers , print_available_inquirers

# print(
print_available_executors()
# )


# print(
print_available_inquirers()
# )

# print(
save_last_executor()
# )