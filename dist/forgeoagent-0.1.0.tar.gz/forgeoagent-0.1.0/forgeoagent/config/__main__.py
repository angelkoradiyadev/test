from .config import DEFAULT_MODEL
print(DEFAULT_MODEL)